const bonito = document.getElementById("bonito");

function slide1(){
    bonito.src="img1.jpg"
    setTimeout (slide2, 1500)
}
function slide2(){
    bonito.src="img2.webp"
    setTimeout (slide3, 1500)
}
function slide3(){
    bonito.src="img3.webp"
    setTimeout (slide1, 1500)
}

slide1 ();

